DashboardScreen = {
  show: function(){
    var self = this;
    $('.dashboard-screen').show();

    var t = setTimeout(function(){
      self.startAnimation();
    }, 1000);
  },
  startAnimation:function(callback){
    var animationQueue = [
      DashboardScreen.showMessage,
      DashboardScreen.showStepOne,
      DashboardScreen.showLaptop,
      DashboardScreen.drawLineLeft,
      DashboardScreen.showStepTwo,
      DashboardScreen.showCloud,
      DashboardScreen.drawLineRight,
      DashboardScreen.showStepThree,
      DashboardScreen.showAdmoUnit,
      DashboardScreen.clearScreen,
      DashboardScreen.startAnimation
    ]

    App.animateQueue(animationQueue);
    setTimeout(callback, App.mediumSpeed);
  },
  clearScreen:function(callback){
    $('.dashboard-screen *').removeClass('animate');

    setTimeout(callback, App.mediumSpeed);
  },
  showLaptop:function(callback){
    $('.laptop').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showStepOne:function(callback){
    $('.step.one').addClass('animate');
    $('.shadow.one').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showStepThree:function(callback){
    $('.step.three').addClass('animate');
    $('.shadow.three').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showStepTwo:function(callback){
    $('.step.two').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  drawLineLeft:function(callback){
    $('.line.left').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  drawLineRight:function(callback){
    $('.line.right').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showCloud:function(callback){
    $('.cloud').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showAdmoUnit:function(callback){
    $('.admo-unit').addClass('animate');
    setTimeout(callback, App.mediumSpeed);
  },
  showMessage:function(callback){
    $('.dashboard-screen .message').fadeIn(App.mediumSpeed);
    setTimeout(callback, App.mediumSpeed);
  }

};
