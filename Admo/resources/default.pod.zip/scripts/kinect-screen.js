KinectScreen = {
  show: function(){
    $('.kinect-screen').show();

    var animationQueue = [
      this.showKinect,
      this.showKinectMessage,
      this.showArrow
    ]

    App.animateQueue(animationQueue);
  },
  showKinect:function(callback){
    $('.kinect').fadeIn();
    setTimeout(callback, 1000);
  },
  showKinectMessage:function(callback){
    $('.kinect-screen .message').fadeIn();
    setTimeout(callback, 1000);
  },
  showArrow:function(callback){
    $('.arrow').fadeIn();
    setTimeout(callback, 1000);
  },
  hide:function(){
    $('.kinect-screen').fadeOut();
  }
};
