console.log('js loaded');

var App = {
  slowSpeed: 2000,
  mediumSpeed: 1000,
  fastSpeed: 500,
  animateQueue:function(queue){
    console.log(queue);
    if (queue.length < 1) {
      return;
    }

    var self = this;
    var f = queue.shift();

    f.call(this, function(){
      self.animateQueue(queue);
    });
  },
  showDashboardScreen: function(){
    $('.kinect-screen').fadeOut();
    $('.dashboard-screen').fadeIn();
  }
}
